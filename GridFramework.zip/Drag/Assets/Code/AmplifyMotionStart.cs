﻿using UnityEngine;
using System.Collections;

public class AmplifyMotionStart : MonoBehaviour {

	// Use this for initialization
	void Start () {
        this.gameObject.AddComponent<AmplifyMotionObjectBase>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
