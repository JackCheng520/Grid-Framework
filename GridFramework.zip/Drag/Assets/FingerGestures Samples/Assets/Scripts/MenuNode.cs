using UnityEngine;
using System.Collections;

public class MenuNode : MonoBehaviour 
{
    public string sceneName;
}
