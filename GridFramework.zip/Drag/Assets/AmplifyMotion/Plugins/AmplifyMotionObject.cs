// Amplify Motion - Full-scene Motion Blur for Unity Pro
// Copyright (c) Amplify Creations, Lda <info@amplify.pt>

using System;
using UnityEngine;

[AddComponentMenu( "Image Effects/Amplify Motion Object" )]
public class AmplifyMotionObject : AmplifyMotionObjectBase
{
}